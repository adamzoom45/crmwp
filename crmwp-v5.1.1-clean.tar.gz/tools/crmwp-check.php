<?php
declare(strict_types=1);

/**
 * CRMWP Structure Check v1.1
 *
 * Updated for real CRMWP structure:
 * - WordPress tables: wp_akpp_*
 * - options: akpp_*
 * - pages: lk, shop, cart, uslugi, garantiya, oferta
 *
 * Read-only diagnostic.
 */

error_reporting(E_ALL);
ini_set('display_errors', '1');

define('CRMWP_CHECK_VERSION', '1.1');

$options = getopt('', [
    'db',
    'pages',
    'json',
    'verbose',
    'no-lint',
    'wp-load::',
    'theme-root::',
]);

// Pages require WordPress.
if (isset($options['pages'])) {
    $options['db'] = true;
}

$base = rtrim($options['theme-root'] ?? getcwd(), "/\\");
if ($base === '') {
    $base = (string)getcwd();
}

$report = [
    'tool' => 'CRMWP Structure Check',
    'version' => CRMWP_CHECK_VERSION,
    'time' => date('Y-m-d H:i:s'),
    'php' => PHP_VERSION,
    'root' => $base,
    'summary' => [
        'ok' => 0,
        'warn' => 0,
        'fail' => 0,
    ],
    'checks' => [],
    'errors' => [],
    'warnings' => [],
];

function rpt_add(array &$r, string $type, string $name, string $status, string $message = ''): void
{
    if (!in_array($status, ['ok', 'warn', 'fail'], true)) {
        $status = 'fail';
    }

    $r['checks'][] = [
        'type' => $type,
        'name' => $name,
        'status' => $status,
        'message' => $message,
    ];

    if ($status === 'ok') {
        $r['summary']['ok']++;
    } elseif ($status === 'warn') {
        $r['summary']['warn']++;
        $r['warnings'][] = $name . ($message !== '' ? " — $message" : '');
    } else {
        $r['summary']['fail']++;
        $r['errors'][] = $name . ($message !== '' ? " — $message" : '');
    }
}

function rpt_path(string $base, string $rel): string
{
    return $base . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $rel);
}

function rpt_check_file(array &$r, string $base, string $rel, bool $required): void
{
    $path = rpt_path($base, $rel);

    if (is_file($path)) {
        $size = filesize($path);
        rpt_add($r, 'file', $rel, 'ok', number_format((float)$size, 0, '.', ' ') . ' B');
    } else {
        rpt_add(
            $r,
            'file',
            $rel,
            $required ? 'fail' : 'warn',
            $required ? 'обязательный файл не найден' : 'файл не найден'
        );
    }
}

function rpt_check_dir(array &$r, string $base, string $rel, bool $required): void
{
    $path = rpt_path($base, $rel);

    if (is_dir($path)) {
        rpt_add($r, 'dir', $rel, 'ok');
    } else {
        rpt_add(
            $r,
            'dir',
            $rel,
            $required ? 'fail' : 'warn',
            $required ? 'обязательная директория не найдена' : 'директория не найдена'
        );
    }
}

function rpt_scan_php(string $base): array
{
    $files = [];

    $rootPhp = glob($base . DIRECTORY_SEPARATOR . '*.php');
    if (is_array($rootPhp)) {
        foreach ($rootPhp as $f) {
            $files[] = $f;
        }
    }

    foreach (['inc'] as $sub) {
        $path = $base . DIRECTORY_SEPARATOR . $sub;
        if (!is_dir($path)) {
            continue;
        }

        try {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)
            );

            foreach ($iterator as $file) {
                $pathname = $file->getPathname();

                if (
                    strpos($pathname, 'node_modules') !== false ||
                    strpos($pathname, 'vendor') !== false ||
                    strpos($pathname, '.git') !== false
                ) {
                    continue;
                }

                if ($file->isFile() && strtolower((string)$file->getExtension()) === 'php') {
                    $files[] = $pathname;
                }
            }
        } catch (Throwable $e) {
            // ignore scan errors
        }
    }

    return array_values(array_unique($files));
}

function rpt_lint(array &$r, string $base, array $files): void
{
    if (!function_exists('exec')) {
        rpt_add($r, 'lint', 'exec()', 'warn', 'exec() недоступен, php -l пропущен');
        return;
    }

    $bin = defined('PHP_BINARY') && PHP_BINARY !== '' ? PHP_BINARY : 'php';

    if (count($files) > 500) {
        rpt_add($r, 'lint', 'limit', 'warn', 'проверяются первые 500 PHP-файлов');
        $files = array_slice($files, 0, 500);
    }

    foreach ($files as $file) {
        $cmd = sprintf(
            '%s -l %s 2>&1',
            escapeshellarg($bin),
            escapeshellarg($file)
        );

        $out = [];
        $code = 0;
        @exec($cmd, $out, $code);

        $rel = str_replace($base . DIRECTORY_SEPARATOR, '', $file);

        if ($code === 0) {
            rpt_add($r, 'lint', $rel, 'ok');
        } else {
            rpt_add($r, 'lint', $rel, 'fail', implode(' | ', array_slice($out, 0, 2)));
        }
    }
}

function rpt_markers(array &$r, string $base): void
{
    $markers = [
        '8c-3b-C-fix',
        'manual-load-fix-8c3b',
        'dedup-fix-8d',
    ];

    $files = rpt_scan_php($base);
    $found = [];

    foreach ($files as $file) {
        if (!is_file($file)) {
            continue;
        }

        $content = @file_get_contents($file);
        if ($content === false) {
            continue;
        }

        foreach ($markers as $marker) {
            if (strpos($content, $marker) !== false) {
                $found[$marker][] = str_replace($base . DIRECTORY_SEPARATOR, '', $file);
            }
        }
    }

    foreach ($markers as $marker) {
        if (isset($found[$marker])) {
            rpt_add($r, 'marker', $marker, 'ok', count($found[$marker]) . ' файлов');
        } else {
            rpt_add($r, 'marker', $marker, 'warn', 'маркер не найден');
        }
    }
}

function rpt_find_wp_load(string $base, string $override): string
{
    if ($override !== '') {
        if (is_file($override)) {
            return $override;
        }

        $path = rpt_path($base, $override);
        if (is_file($path)) {
            return $path;
        }

        return '';
    }

    $candidates = [
        getcwd() . DIRECTORY_SEPARATOR . 'wp-load.php',
        $base . DIRECTORY_SEPARATOR . 'wp-load.php',
    ];

    foreach ([1, 2, 3, 4, 5] as $level) {
        $candidates[] = dirname($base, $level) . DIRECTORY_SEPARATOR . 'wp-load.php';
    }

    foreach ($candidates as $candidate) {
        if (is_file($candidate)) {
            return $candidate;
        }
    }

    return '';
}

function rpt_mask_option(string $key, $value): string
{
    if (is_array($value) || is_object($value)) {
        $value = json_encode($value, JSON_UNESCAPED_UNICODE);
    }

    $s = (string)$value;

    if (preg_match('/key|token|secret|license|password|private/i', $key) && strlen($s) > 8) {
        return substr($s, 0, 4) . '...' . substr($s, -4);
    }

    if (strlen($s) > 120) {
        return substr($s, 0, 117) . '...';
    }

    return $s;
}

function rpt_find_table(array $tables, string $prefix, string $short): ?string
{
    $candidates = [
        $prefix . 'akpp_' . $short,
        'akpp_' . $short,
    ];

    foreach ($candidates as $table) {
        if (in_array($table, $tables, true)) {
            return $table;
        }
    }

    return null;
}

function rpt_get_columns($wpdb, string $table): array
{
    $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
    if ($safe === '') {
        return [];
    }

    return (array)$wpdb->get_col("SHOW COLUMNS FROM `$safe`", 0);
}

function rpt_check_column(array &$r, $wpdb, ?string $table, string $column, bool $required = false): void
{
    if ($table === null) {
        return;
    }

    $cols = rpt_get_columns($wpdb, $table);

    if (in_array($column, $cols, true)) {
        rpt_add($r, 'column', $table . '.' . $column, 'ok');
    } else {
        rpt_add(
            $r,
            'column',
            $table . '.' . $column,
            $required ? 'fail' : 'warn',
            'колонка не найдена'
        );
    }
}

function rpt_has_column_like($wpdb, string $table, string $needle): bool
{
    foreach (rpt_get_columns($wpdb, $table) as $col) {
        if (stripos($col, $needle) !== false) {
            return true;
        }
    }

    return false;
}

function rpt_db(array &$r, string $wpLoad, bool $checkPages): void
{
    if ($wpLoad === '' || !is_file($wpLoad)) {
        rpt_add(
            $r,
            'db',
            'wp-load.php',
            'fail',
            'не найден; запусти без --db или укажи --wp-load=путь'
        );
        return;
    }

    if (!defined('ABSPATH')) {
        define('ABSPATH', rtrim(dirname($wpLoad), "/\\") . DIRECTORY_SEPARATOR);
    }

    require_once $wpLoad;

    global $wpdb;
    if (!isset($wpdb)) {
        $wpdb = $GLOBALS['wpdb'] ?? null;
    }

    if (!isset($wpdb)) {
        rpt_add($r, 'db', 'wpdb', 'fail', 'WordPress загружен, но $wpdb недоступен');
        return;
    }

    $wpVersion = isset($GLOBALS['wp_version']) ? $GLOBALS['wp_version'] : 'loaded';
    rpt_add($r, 'db', 'WordPress', 'ok', 'WP ' . $wpVersion);

    $prefix = (string)$wpdb->prefix;
    rpt_add($r, 'db', 'prefix', 'ok', $prefix);

    $tables = (array)$wpdb->get_col('SHOW TABLES');

    $custom = array_values(array_filter($tables, function (string $t): bool {
        return strpos($t, 'akpp_') !== false || strpos($t, 'crm_') !== false;
    }));

    rpt_add(
        $r,
        'db',
        'custom tables',
        count($custom) > 0 ? 'ok' : 'fail',
        count($custom) . ' шт.'
    );

    $coreTables = [
        'site_users',
        'vehicles',
        'deals',
        'deal_parts',
        'parts',
        'services',
        'leads',
        'licenses',
    ];

    $optionalTables = [
        'agreements',
        'attendance',
        'cars',
        'deal_services',
        'employees',
        'oils',
        'part_categories',
        'parser_items',
        'push_tokens',
        'salary_manual',
        'service_categories',
        'service_parts',
        'shop_cart',
        'shop_order_messages',
        'shop_orders',
        'timesheet',
        '1c_log',
        'avito_tokens',
    ];

    $found = [];

    foreach ($coreTables as $short) {
        $table = rpt_find_table($tables, $prefix, $short);
        $found[$short] = $table;

        if ($table !== null) {
            rpt_add($r, 'table', $table, 'ok');
        } else {
            rpt_add($r, 'table', 'akpp_' . $short, 'fail', 'обязательная таблица не найдена');
        }
    }

    foreach ($optionalTables as $short) {
        $table = rpt_find_table($tables, $prefix, $short);
        $found[$short] = $table;

        if ($table !== null) {
            rpt_add($r, 'table', $table, 'ok');
        } else {
            rpt_add($r, 'table', 'akpp_' . $short, 'warn', 'опциональная таблица не найдена');
        }
    }

    foreach (array_slice($custom, 0, 60) as $table) {
        $safe = preg_replace('/[^a-zA-Z0-9_]/', '', $table);
        if ($safe === '') {
            continue;
        }

        $count = $wpdb->get_var("SELECT COUNT(*) FROM `$safe`");

        if ($wpdb->last_error !== '') {
            rpt_add($r, 'db', $safe, 'warn', 'count error: ' . $wpdb->last_error);
        } else {
            rpt_add($r, 'db', $safe, 'ok', 'записей: ' . (int)$count);
        }
    }

    rpt_check_column($r, $wpdb, $found['site_users'] ?? null, 'registered_at', false);
    rpt_check_column($r, $wpdb, $found['deal_parts'] ?? null, 'part_id', false);
    rpt_check_column($r, $wpdb, $found['deal_parts'] ?? null, 'part_name', false);

    if (!empty($found['deals'])) {
        if (rpt_has_column_like($wpdb, $found['deals'], 'direction')) {
            rpt_add($r, 'column', $found['deals'] . '.direction-like', 'ok');
        } else {
            rpt_add(
                $r,
                'column',
                $found['deals'] . '.direction-like',
                'warn',
                'колонка направления работ не найдена, возможно имя отличается'
            );
        }
    }

    if (!empty($found['shop_cart'])) {
        rpt_check_column($r, $wpdb, $found['shop_cart'], 'session_id', false);
        rpt_check_column($r, $wpdb, $found['shop_cart'], 'product_id', false);
    }

    if (!empty($found['shop_orders'])) {
        rpt_check_column($r, $wpdb, $found['shop_orders'], 'status', false);
        rpt_check_column($r, $wpdb, $found['shop_orders'], 'total_amount', false);
    }

    if (defined('DB_NAME') && DB_NAME !== '') {
        $sql = "
            SELECT
                TABLE_NAME,
                COLUMN_NAME,
                REFERENCED_TABLE_NAME,
                REFERENCED_COLUMN_NAME
            FROM information_schema.KEY_COLUMN_USAGE
            WHERE TABLE_SCHEMA = %s
              AND REFERENCED_TABLE_NAME IS NOT NULL
        ";

        $fks = (array)$wpdb->get_results($wpdb->prepare($sql, DB_NAME));

        if ($wpdb->last_error !== '') {
            rpt_add($r, 'db', 'FK check', 'warn', 'FK info unavailable: ' . $wpdb->last_error);
        } else {
            $bad = [];

            foreach ($fks as $fk) {
                if (!isset($fk->COLUMN_NAME, $fk->REFERENCED_TABLE_NAME)) {
                    continue;
                }

                if (
                    $fk->COLUMN_NAME === 'part_id' &&
                    stripos($fk->REFERENCED_TABLE_NAME, 'akpp_parts') !== false
                ) {
                    $bad[] = sprintf(
                        '%s.%s -> %s.%s',
                        $fk->TABLE_NAME,
                        $fk->COLUMN_NAME,
                        $fk->REFERENCED_TABLE_NAME,
                        $fk->REFERENCED_COLUMN_NAME
                    );
                }
            }

            if (count($bad) > 0) {
                rpt_add(
                    $r,
                    'db',
                    'FK risk',
                    'warn',
                    'найден рискованный FK: ' . implode(' | ', $bad)
                );
            } else {
                rpt_add(
                    $r,
                    'db',
                    'FK check',
                    'ok',
                    'FK найдено: ' . count($fks) . '; критичных part_id -> akpp_parts не найдено'
                );
            }
        }
    }

    $requiredOptions = [
        'akpp_crm_db_version',
    ];

    $importantOptions = [
        'akpp_master_mode',
        'akpp_site_template',
        'akpp_shop_enabled',
    ];

    $optionalOptions = [
        'akpp_company_name',
        'akpp_company_inn',
        'akpp_tg_chat_id',
        'akpp_license_token',
        'akpp_license_key',
        'akpp_license_status',
        'akpp_public_key',
        'akpp_tenant_id',
    ];

    foreach ($requiredOptions as $key) {
        $value = get_option($key);

        if ($value === false) {
            rpt_add($r, 'option', $key, 'fail', 'обязательная опция не задана');
        } else {
            rpt_add($r, 'option', $key, 'ok', rpt_mask_option($key, $value));
        }
    }

    foreach ($importantOptions as $key) {
        $value = get_option($key);

        if ($value === false) {
            rpt_add($r, 'option', $key, 'warn', 'важная опция не задана');
        } else {
            rpt_add($r, 'option', $key, 'ok', rpt_mask_option($key, $value));
        }
    }

    foreach ($optionalOptions as $key) {
        $value = get_option($key);

        if ($value !== false) {
            rpt_add($r, 'option', $key, 'ok', rpt_mask_option($key, $value));
        }
    }

    $licenseKeys = [
        'akpp_license_token',
        'akpp_license_key',
        'akpp_license_status',
        'akpp_public_key',
    ];

    $licenseFound = false;
    foreach ($licenseKeys as $key) {
        if (get_option($key) !== false) {
            $licenseFound = true;
            break;
        }
    }

    if (!$licenseFound) {
        rpt_add(
            $r,
            'option',
            'license options',
            'warn',
            'лицензионные опции не найдены'
        );
    }

    if ($checkPages && function_exists('get_page_by_path')) {
        $slugs = [
            'lk',
            'shop',
            'cart',
            'uslugi',
            'garantiya',
            'oferta',
        ];

        foreach ($slugs as $slug) {
            $page = get_page_by_path($slug);

            if ($page instanceof WP_Post) {
                rpt_add($r, 'page', '/' . $slug . '/', 'ok', 'id=' . $page->ID);
            } else {
                rpt_add($r, 'page', '/' . $slug . '/', 'warn', 'страница не найдена');
            }
        }
    }
}

// Basic structure.
rpt_check_file($report, $base, 'functions.php', true);
rpt_check_file($report, $base, 'header.php', false);
rpt_check_file($report, $base, 'footer.php', false);
rpt_check_file($report, $base, 'index.php', false);
rpt_check_file($report, $base, 'style.css', false);
rpt_check_file($report, $base, 'README.md', false);

rpt_check_dir($report, $base, 'inc/crm', true);
rpt_check_dir($report, $base, 'inc/crm/ajax', false);
rpt_check_dir($report, $base, 'inc/crm/tests', false);
rpt_check_file($report, $base, 'inc/crm/tests/crm-regression-test.php', false);

$phpFiles = rpt_scan_php($base);
rpt_add($report, 'scan', 'PHP-файлы', 'ok', count($phpFiles) . ' шт.');

if (!isset($options['no-lint'])) {
    rpt_lint($report, $base, $phpFiles);
}

rpt_markers($report, $base);

// Version constant.
$versionFound = false;
foreach ($phpFiles as $file) {
    $content = @file_get_contents($file);
    if ($content === false) {
        continue;
    }

    if (preg_match(
        '/define\s*\(\s*[\'"]AKPP_(?:THEME|CRM)_VERSION[\'"]\s*,\s*[\'"]([^\'"]+)[\'"]/',
        $content,
        $m
    )) {
        $rel = str_replace($base . DIRECTORY_SEPARATOR, '', $file);
        rpt_add($report, 'version', 'AKPP version', 'ok', $m[1] . ' in ' . $rel);
        $versionFound = true;
        break;
    }
}

if (!$versionFound) {
    rpt_add(
        $report,
        'version',
        'AKPP_THEME_VERSION / AKPP_CRM_VERSION',
        'warn',
        'константа версии не найдена'
    );
}

// functions.php stats.
$functionsPath = rpt_path($base, 'functions.php');
if (is_file($functionsPath)) {
    $content = @file_get_contents($functionsPath);

    if ($content !== false) {
        $lines = file($functionsPath, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $lineCount = is_array($lines) ? count($lines) : 0;

        if ($lineCount > 1200) {
            rpt_add($report, 'functions.php', 'line count', 'warn', "$lineCount строк, файл слишком большой");
        } else {
            rpt_add($report, 'functions.php', 'line count', 'ok', "$lineCount строк");
        }

        $ajaxCount = substr_count($content, 'wp_ajax_');
        if ($ajaxCount > 35) {
            rpt_add(
                $report,
                'functions.php',
                'wp_ajax hooks',
                'warn',
                "найдено $ajaxCount wp_ajax_ hooks, лучше вынести в модули"
            );
        } else {
            rpt_add($report, 'functions.php', 'wp_ajax hooks', 'ok', "найдено $ajaxCount");
        }
    }
}

// AJAX module folder.
$ajaxDir = rpt_path($base, 'inc/crm/ajax');
if (is_dir($ajaxDir)) {
    $ajaxFiles = glob($ajaxDir . DIRECTORY_SEPARATOR . '*.php');
    $ajaxCount = is_array($ajaxFiles) ? count($ajaxFiles) : 0;
    rpt_add($report, 'ajax', 'inc/crm/ajax', 'ok', "$ajaxCount файлов");
} else {
    rpt_add($report, 'ajax', 'inc/crm/ajax', 'warn', 'папка AJAX-модулей не найдена');
}

// Permissions.
foreach ($phpFiles as $file) {
    $perm = @substr(sprintf('%o', @fileperms($file)), -4);

    if ($perm === '0777' || $perm === '0666') {
        rpt_add(
            $report,
            'permissions',
            str_replace($base . DIRECTORY_SEPARATOR, '', $file),
            'warn',
            "небезопасные права $perm"
        );
    }
}

// Optional regression result files.
foreach (['/tmp/crm_result.txt', '/tmp/shop_result.txt'] as $resultFile) {
    if (is_file($resultFile)) {
        $lines = file($resultFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
        $last = is_array($lines) ? trim(implode(' | ', array_slice($lines, -2))) : '';
        rpt_add($report, 'regression', basename($resultFile), 'ok', $last);
    }
}

// Database and pages.
if (isset($options['db'])) {
    $wpLoad = rpt_find_wp_load(
        $base,
        isset($options['wp-load']) ? (string)$options['wp-load'] : ''
    );

    rpt_db($report, $wpLoad, isset($options['pages']));
}

// Output.
if (isset($options['json'])) {
    echo json_encode($report, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit($report['summary']['fail'] > 0 ? 1 : 0);
}

echo "=== CRMWP STRUCTURE CHECK v" . CRMWP_CHECK_VERSION . " ===\n";
echo "Root: {$report['root']}\n";
echo "PHP: {$report['php']}\n";
echo "Time: {$report['time']}\n\n";

$shown = 0;

foreach ($report['checks'] as $check) {
    if ($check['status'] === 'ok' && !isset($options['verbose'])) {
        continue;
    }

    printf(
        "[%s] %-10s %s%s\n",
        strtoupper($check['status']),
        $check['type'],
        $check['name'],
        $check['message'] !== '' ? ' — ' . $check['message'] : ''
    );

    $shown++;
}

if ($shown === 0) {
    echo "Все проверки завершены без предупреждений и ошибок.\n";
}

echo "\nИтог: OK={$report['summary']['ok']}, WARN={$report['summary']['warn']}, FAIL={$report['summary']['fail']}\n";

if (count($report['errors']) > 0) {
    echo "\nОшибки:\n";
    foreach ($report['errors'] as $error) {
        echo " - $error\n";
    }
}

if (count($report['warnings']) > 0) {
    echo "\nПредупреждения:\n";
    foreach ($report['warnings'] as $warning) {
        echo " - $warning\n";
    }
}

exit($report['summary']['fail'] > 0 ? 1 : 0);