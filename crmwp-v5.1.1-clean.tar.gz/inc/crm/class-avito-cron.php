<?php
/**
 * АКПП45 CRM - Cron Авито: делегирует синхронизацию новому мессенджеру v2.
 * Старые вызовы /messages/1/dialogs удалены.
 *
 * @package AKPP_CRM
 * @version 5.1.1
 */

if (!defined('ABSPATH')) exit;

class AKPP_Avito_Cron {

    public function __construct() {
        add_filter('cron_schedules', [$this, 'add_custom_cron_interval']);
        add_action('wp', [$this, 'schedule_sync_event']);
        add_action('akpp_avito_sync_dialogs_hook', [$this, 'run_sync']);
    }

    public function add_custom_cron_interval($schedules) {
        $schedules['every_15_minutes'] = ['interval' => 900, 'display' => __('Каждые 15 минут', 'akpp-crm')];
        return $schedules;
    }

    public function schedule_sync_event() {
        if (!get_option('akpp_avito_auto_sync', 0)) {
            $this->clear_sync_event();
            return;
        }
        if (!wp_next_scheduled('akpp_avito_sync_dialogs_hook')) {
            wp_schedule_event(time(), 'every_15_minutes', 'akpp_avito_sync_dialogs_hook');
        }
    }

    public function clear_sync_event() {
        $t = wp_next_scheduled('akpp_avito_sync_dialogs_hook');
        if ($t) wp_unschedule_event($t, 'akpp_avito_sync_dialogs_hook');
    }

    public function run_sync() {
        if (get_transient('akpp_avito_sync_lock')) return;
        set_transient('akpp_avito_sync_lock', true, 10 * MINUTE_IN_SECONDS);
        try {
            if (class_exists('AKPP_Avito_Messenger')) {
                $r = AKPP_Avito_Messenger::get_instance()->sync_all();
                if (!empty($r['error'])) error_log('[AKPP Avito Cron] sync error: ' . $r['error']);
            }
        } finally {
            delete_transient('akpp_avito_sync_lock');
        }
    }
}
