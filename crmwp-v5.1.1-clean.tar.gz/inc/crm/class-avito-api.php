<?php
/**
 * АКПП45 CRM - Avito API v2 (OAuth2 Client Credentials)
 * Поддержка: мессенджер v2, объявления, доставка, автотека.
 * С ноября 2025: Messenger API требует платную подписку "Расширенный" или "Максимальный".
 *
 * @package AKPP_CRM
 * @version 5.1.1
 */

if (!defined('ABSPATH')) exit;

class AKPP_Avito_API {
    private static $instance = null;
    
    private $client_id;
    private $client_secret;
    private $api_base = 'https://api.avito.ru';
    private $token_endpoint = 'https://api.avito.ru/token';
    
    public static function get_instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }
    
    private function __construct() {
        add_action('admin_post_akpp_save_avito_settings', [$this, 'handle_save_settings']); // akpp-avito-save-handler
        $this->client_id = (string) get_option('akpp_avito_client_id', '');
        $this->client_secret = (string) get_option('akpp_avito_client_secret', '');
    }
    
    /**
     * Получить валидный access_token (с кэшированием).
     * Токен живёт 24ч, обновляем за 60 сек до истечения.
     *
     * @return string|WP_Error
     */
    public function get_access_token() {
        $cached = get_option('akpp_avito_token_data', null);
        
        if ($cached && !empty($cached['access_token']) && !empty($cached['expires_at'])) {
            if (time() < ($cached['expires_at'] - 60)) {
                return $cached['access_token'];
            }
        }
        
        return $this->fetch_new_token();
    }
    
    /**
     * Запрос нового токена у Avito (OAuth2 Client Credentials).
     *
     * @return string|WP_Error
     */
    private function fetch_new_token() {
        if (empty($this->client_id) || empty($this->client_secret)) {
            return new WP_Error('avito_missing_credentials', 'Не указаны Client ID или Client Secret в настройках Avito.');
        }
        
        $response = wp_remote_post($this->token_endpoint, [
            'body' => [
                'grant_type'    => 'client_credentials',
                'client_id'     => $this->client_id,
                'client_secret' => $this->client_secret,
            ],
            'timeout' => 15,
        ]);
        
        if (is_wp_error($response)) {
            $this->log_error('Token Request Failed', $response->get_error_message());
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code !== 200 || empty($body['access_token'])) {
            $err = $body['error_description'] ?? $body['error'] ?? 'Unknown error';
            $this->log_error('Token Fetch Failed', $err . " (HTTP $code)");
            return new WP_Error('avito_token_error', $err);
        }
        
        $expires_in = isset($body['expires_in']) ? (int) $body['expires_in'] : 86400;
        update_option('akpp_avito_token_data', [
            'access_token' => $body['access_token'],
            'expires_at'   => time() + $expires_in,
        ]);
        
        $this->log_info('Token refreshed (expires in ' . $expires_in . 's)');
        return $body['access_token'];
    }
    
    /**
     * Получить User ID текущего аккаунта (кэшируется в опции).
     *
     * @return int|WP_Error
     */
    public function get_user_id() {
        $cached = (int) get_option('akpp_avito_user_id', 0);
        if ($cached > 0) return $cached;
        
        $response = $this->make_request('/core/v1/accounts/self');
        if (is_wp_error($response)) return $response;
        
        $user_id = (int) ($response['id'] ?? 0);
        if ($user_id > 0) {
            update_option('akpp_avito_user_id', $user_id);
            return $user_id;
        }
        
        return new WP_Error('avito_user_id_error', 'Не удалось получить User ID');
    }
    
    /**
     * Универсальный метод запроса к Avito API.
     * Автоматически добавляет Bearer token, retry на 401 (один раз).
     *
     * @param string $endpoint Путь (например, '/messenger/v2/accounts/{user_id}/chats')
     * @param string $method   HTTP метод (GET, POST, PUT, DELETE)
     * @param array  $body     Тело запроса (для POST/PUT/PATCH)
     * @return array|WP_Error  Декодированный JSON или ошибка
     */
    public function make_request($endpoint, $method = 'GET', $body = null) {
        $token = $this->get_access_token();
        if (is_wp_error($token)) return $token;
        
        $url = $this->api_base . $endpoint;
        $args = [
            'method'  => strtoupper($method),
            'headers' => [
                'Authorization' => 'Bearer ' . $token,
                'Content-Type'  => 'application/json',
                'Accept'        => 'application/json',
            ],
            'timeout' => 15,
        ];
        
        if ($body && in_array(strtoupper($method), ['POST', 'PUT', 'PATCH'], true)) {
            $args['body'] = wp_json_encode($body);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            $this->log_error("API Request Failed ($method $endpoint)", $response->get_error_message());
            return $response;
        }
        
        $code = wp_remote_retrieve_response_code($response);
        $resp_body = json_decode(wp_remote_retrieve_body($response), true);
        
        if ($code >= 400) {
            // Retry один раз на 401 (токен протух)
            if ($code === 401) {
                delete_option('akpp_avito_token_data');
                $new_token = $this->fetch_new_token();
                if (!is_wp_error($new_token)) {
                    $args['headers']['Authorization'] = 'Bearer ' . $new_token;
                    $retry = wp_remote_request($url, $args);
                    if (!is_wp_error($retry)) {
                        $retry_code = wp_remote_retrieve_response_code($retry);
                        $retry_body = json_decode(wp_remote_retrieve_body($retry), true);
                        if ($retry_code < 400) return $retry_body ?: [];
                        $code = $retry_code;
                        $resp_body = $retry_body;
                    }
                }
            }
            
            $err_msg = $resp_body['error'] ?? $resp_body['error_description'] ?? 'API Error';
            $this->log_error("API Error $code ($endpoint)", $err_msg);
            return new WP_Error('avito_api_error', $err_msg, ['status' => $code, 'data' => $resp_body]);
        }
        
        return $resp_body ?: [];
    }
    
    /**
     * Получить список чатов (messenger v2).
     *
     * @param int $limit Максимум 100
     * @return array|WP_Error
     */
    public function get_chats($limit = 50) {
        $user_id = $this->get_user_id();
        if (is_wp_error($user_id)) return $user_id;
        
        $limit = min(100, max(1, (int) $limit));
        return $this->make_request("/messenger/v2/accounts/{$user_id}/chats?limit={$limit}");
    }
    
    /**
     * Получить сообщения чата (messenger v2).
     *
     * @param string $chat_id  ID чата
     * @param int    $limit    Максимум 100
     * @return array|WP_Error
     */
    public function get_chat_messages($chat_id, $limit = 50) {
        $user_id = $this->get_user_id();
        if (is_wp_error($user_id)) return $user_id;
        
        $limit = min(100, max(1, (int) $limit));
        return $this->make_request("/messenger/v2/accounts/{$user_id}/chats/{$chat_id}/messages?limit={$limit}");
    }
    
    /**
     * Отправить текстовое сообщение (messenger v1 — актуальный эндпоинт для отправки).
     *
     * @param string $chat_id ID чата
     * @param string $text    Текст сообщения
     * @return array|WP_Error
     */
    public function send_message($chat_id, $text) {
        $user_id = $this->get_user_id();
        if (is_wp_error($user_id)) return $user_id;
        
        return $this->make_request("/messenger/v1/accounts/{$user_id}/chats/{$chat_id}/messages", 'POST', [
            'type'    => 'text',
            'message' => ['text' => (string) $text],
        ]);
    }
    
    /**
     * Отметить сообщение прочитанным.
     *
     * @param string $chat_id    ID чата
     * @param string $message_id ID сообщения
     * @return array|WP_Error
     */
    public function mark_message_read($chat_id, $message_id) {
        $user_id = $this->get_user_id();
        if (is_wp_error($user_id)) return $user_id;
        
        return $this->make_request("/messenger/v2/accounts/{$user_id}/chats/{$chat_id}/messages/{$message_id}/read", 'POST');
    }
    
    /** Сохранение настроек Avito + получение токена (action из шаблона настроек) */
    public function handle_save_settings() {
        if (!current_user_can('akpp_manage_integrations')) wp_die('Недостаточно прав');
        check_admin_referer('akpp_avito_settings_nonce');
        $cid = $_POST['client_id'] ?? $_POST['akpp_avito_client_id'] ?? null;
        if ($cid !== null) update_option('akpp_avito_client_id', sanitize_text_field(wp_unslash($cid)));
        $sec = trim((string) ($_POST['client_secret'] ?? $_POST['akpp_avito_client_secret'] ?? ''));
        if ($sec !== '') update_option('akpp_avito_client_secret', $sec);
        delete_option('akpp_avito_token_data');
        delete_transient('akpp_avito_items');
        $t = $this->get_access_token();
        $ok = !is_wp_error($t);
        wp_safe_redirect(admin_url('admin.php?page=akpp-crm-avito-dialogs&tab=settings&avito_saved=' . ($ok ? 1 : 0)));
        exit;
    }
    private function log_error($context, $msg) {
        error_log(sprintf('[AKPP Avito API] ERROR: %s - %s', $context, $msg));
    }
    
    private function log_info($msg) {
        error_log(sprintf('[AKPP Avito API] INFO: %s', $msg));
    }
}
