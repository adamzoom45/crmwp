<?php
/**
 * Регрессионный автотест CRM — 10 модулей.
 * Запуск:  php inc/crm/tests/crm-regression-test.php > /dev/null 2>&1; cat /tmp/crm_result.txt
 * Проверяет: клиенты, авто, склад, услуги+привязки, сделка (запчасти+услуги+итог в БД и ответе),
 *            подгрузка при редактировании, смена статуса, выручка дашборда, лиды, сотрудники.
 * Безопасен: создаёт и удаляет ТОЛЬКО тестовые данные (метки +79990000001/2, TST-, TESTVIN, Тест Диагностика, master@test.local).
 * Результат: /tmp/crm_result.txt ("10 passed, 0 failed" = зелёный).
 */
if (!defined('DOING_AJAX')) define('DOING_AJAX', true);
require "/home/akpp/htdocs/akpp45.ru/wp-load.php";
error_reporting(E_ERROR);
wp_set_current_user(1);
global $wpdb; $p = $wpdb->prefix;
$now = current_time('mysql'); $ids = []; $res = []; $last = 'start';

$die = function(){ return function($m){ throw new Exception(is_string($m)?$m:'wp_die'); }; };
add_filter('wp_die_handler', $die);
add_filter('wp_die_ajax_handler', $die);

register_shutdown_function(function(){
    global $res, $last;
    $out = "\n=== РЕЗУЛЬТАТЫ АВТОТЕСТОВ CRM v4 (последний этап: $last) ===\n";
    $pass=0;$fail=0;
    foreach ($res as $r){ $out .= sprintf("  [%s] %s%s\n",$r[1]?'PASS':'FAIL',$r[0],$r[2]?" — ".$r[2]:''); $r[1]?$pass++:$fail++; }
    $out .= "\n  ИТОГО: $pass passed, $fail failed (выполнено ".count($res)." из 10)\n";
    file_put_contents('/tmp/crm_result.txt', $out);
});

function cleanup_test_data() {
    global $wpdb, $p;
    foreach ($wpdb->get_col("SELECT id FROM {$p}akpp_site_users WHERE phone='+79990000001'") as $cid) {
        foreach ($wpdb->get_col("SELECT id FROM {$p}akpp_deals WHERE client_id=$cid") as $did)
            { $wpdb->delete($p.'akpp_deal_services',['deal_id'=>$did]); $wpdb->delete($p.'akpp_deal_parts',['deal_id'=>$did]); }
        $wpdb->delete($p.'akpp_deals',['client_id'=>$cid]);
    }
    foreach ($wpdb->get_col("SELECT id FROM {$p}akpp_services WHERE name LIKE 'Тест Диагностика%'") as $sid) $wpdb->delete($p.'akpp_service_parts',['service_id'=>$sid]);
    $wpdb->query("DELETE FROM {$p}akpp_services WHERE name LIKE 'Тест Диагностика%'");
    $wpdb->query("DELETE FROM {$p}akpp_parts WHERE sku LIKE 'TST-%'");
    $wpdb->query("DELETE FROM {$p}akpp_vehicles WHERE vin LIKE 'TESTVIN%'");
    $wpdb->query("DELETE FROM {$p}akpp_leads WHERE client_phone='+79990000002'");
    $wpdb->query("DELETE FROM {$p}akpp_employees WHERE email='master@test.local'");
    $wpdb->query("DELETE FROM {$p}akpp_site_users WHERE phone='+79990000001'");
}
register_shutdown_function('cleanup_test_data');

function t($name, $fn) { global $res, $last; $last = $name;
    try { $res[] = [$name, (bool)$fn(), '']; }
    catch (Throwable $e) { $res[] = [$name, false, $e->getMessage()]; }
}
function ajax($post) {
    $_POST = $post; $_REQUEST = $post; $_SERVER['REQUEST_METHOD']='POST'; $_SERVER['REMOTE_ADDR']='127.0.0.1';
    $o = (new ReflectionClass('AKPP_AJAX_Deals'))->newInstanceWithoutConstructor();
    ob_start();
    try { $o->ajax_save_deal(); } catch (Throwable $e) {}
    $buf = ob_get_clean();
    if (preg_match('/^\\{"success":(?:true|false),"data":\\{[^{}]*\\}\\}/', $buf, $m)) return $m[0];
    return $buf;
}

t('T1 клиент', function() use ($wpdb,$p,$now,&$ids){
    $wpdb->insert($p.'akpp_site_users', ['full_name'=>'Тест АвтоCRM','phone'=>'+79990000001','email'=>'test@crm.local','status'=>'active','registered_at'=>$now]);
    $ids['client']=$wpdb->insert_id; return $ids['client']>0;
});
t('T2 авто', function() use ($wpdb,$p,$now,&$ids){
    $wpdb->insert($p.'akpp_vehicles', ['vin'=>'TESTVIN0000000001','make'=>'Toyota','model'=>'Camry','year'=>2010,'engine'=>'2.4L','created_at'=>$now]);
    $ids['veh']=$wpdb->insert_id; return $ids['veh']>0;
});
t('T3 запчасть склада', function() use ($wpdb,$p,$now,&$ids){
    $wpdb->insert($p.'akpp_parts', ['name'=>'Тест Фильтр АКПП','category'=>'akpp','sku'=>'TST-001','quantity'=>10,'price'=>1500,'purchase_price'=>1000,'created_at'=>$now]);
    $ids['part']=$wpdb->insert_id; return $ids['part']>0;
});
t('T4 услуга + привязка запчасти', function() use ($wpdb,$p,$now,&$ids){
    $wpdb->insert($p.'akpp_services', ['name'=>'Тест Диагностика АКПП','direction'=>'akpp','category_id'=>0,'norm_hours'=>1.5,'price'=>3000,'is_active'=>1,'created_at'=>$now]);
    $ids['svc']=$wpdb->insert_id;
    $wpdb->insert($p.'akpp_service_parts', ['service_id'=>$ids['svc'],'part_id'=>$ids['part'],'qty'=>2]);
    return $ids['svc']>0 && $wpdb->insert_id>0;
});
t('T5 сделка+запчасти+услуга: итог в БД и в ответе', function() use ($wpdb,$p,&$ids){
    $resp = ajax(['nonce'=>wp_create_nonce('akpp45_nonce'),'client_id'=>$ids['client'],'client_name'=>'Тест АвтоCRM','client_phone'=>'+79990000001','brand'=>'Toyota','model'=>'Camry','vehicle_id'=>$ids['veh'],'service_category'=>'akpp','status'=>'new','work_cost'=>2000,'total_amount'=>0,
        'parts'=>[ json_encode(['id'=>$ids['part'],'name'=>'Тест Фильтр АКПП','sku'=>'TST-001','price'=>1500,'quantity'=>1,'source'=>'part']), json_encode(['id'=>0,'name'=>'Тест Ручная','sku'=>'','price'=>500,'quantity'=>1,'source'=>'manual']) ],
        'services'=>[ json_encode(['id'=>$ids['svc'],'name'=>'Тест Диагностика АКПП','quantity'=>1,'norm_hours'=>1.5,'price'=>3000]) ]]);
    $d = json_decode($resp, true);
    if (!$d || empty($d['success'])) throw new Exception("не success, сырьё: ".substr($resp,0,300));
    $ids['deal']=$d['data']['id'];
    $np=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}akpp_deal_parts WHERE deal_id={$ids['deal']}");
    $ns=(int)$wpdb->get_var("SELECT COUNT(*) FROM {$p}akpp_deal_services WHERE deal_id={$ids['deal']}");
    $db_tot=(float)$wpdb->get_var("SELECT total_amount FROM {$p}akpp_deals WHERE id={$ids['deal']}");
    $resp_tot=(float)($d['data']['total_amount']??0);
    if ($np!==2) throw new Exception("запчастей $np (надо 2)");
    if ($ns!==1) throw new Exception("услуг $ns (надо 1)");
    if (abs($db_tot-7000)>0.01) throw new Exception("итог в БД=$db_tot (надо 7000)");
    if (abs($resp_tot-7000)>0.01) throw new Exception("итог в ответе=$resp_tot (надо 7000)");
    return true;
});
t('T6 подгрузка при редактировании (manual-имя + услуга)', function() use ($wpdb,$p,&$ids){
    $dp=$wpdb->get_row($wpdb->prepare("SELECT dp.*, pp.name jn FROM {$p}akpp_deal_parts dp LEFT JOIN {$p}akpp_parts pp ON dp.part_id=pp.id WHERE dp.deal_id=%d AND dp.part_id IS NULL",$ids['deal']),ARRAY_A);
    $name=$dp['part_name']??$dp['jn']??'';
    if ($name!=='Тест Ручная') throw new Exception("manual-имя: [$name]");
    $sv=$wpdb->get_var("SELECT service_name FROM {$p}akpp_deal_services WHERE deal_id={$ids['deal']} LIMIT 1");
    if ($sv!=='Тест Диагностика АКПП') throw new Exception("услуга: [$sv]");
    return true;
});
t('T7 смена статуса → completed', function() use ($wpdb,$p,&$ids){
    $_POST=['nonce'=>wp_create_nonce('akpp45_nonce'),'id'=>$ids['deal'],'status'=>'completed'];
    $_REQUEST=$_POST; $_SERVER['REQUEST_METHOD']='POST'; $_SERVER['REMOTE_ADDR']='127.0.0.1';
    try { (new ReflectionClass('AKPP_AJAX_Deals'))->newInstanceWithoutConstructor()->ajax_update_deal_status(); } catch(Throwable $e){}
    $st=$wpdb->get_var("SELECT status FROM {$p}akpp_deals WHERE id={$ids['deal']}");
    if ($st!=='completed') throw new Exception("статус: $st");
    return true;
});
t('T8 выручка дашборда по completed', function() use ($wpdb,$p,&$ids){
    $wpdb->query("UPDATE {$p}akpp_deals SET created_at=NOW(), updated_at=NOW() WHERE id={$ids['deal']}");
    $rev=(float)$wpdb->get_var("SELECT COALESCE(SUM(total_amount),0) FROM {$p}akpp_deals WHERE status='completed' AND updated_at>=DATE_SUB(NOW(),INTERVAL 1 MONTH) AND id={$ids['deal']}");
    if (abs($rev-7000)>0.01) throw new Exception("выручка=$rev (надо 7000)");
    return true;
});
t('T9 лид', function() use ($wpdb,$p,$now,&$ids){
    $wpdb->insert($p.'akpp_leads', ['client_name'=>'Тест Лид','client_phone'=>'+79990000002','client_agreed'=>1,'status'=>'new','source'=>'site','problem'=>'Тест АКПП','car_brand'=>'Toyota','created_at'=>$now,'updated_at'=>$now]);
    $ids['lead']=$wpdb->insert_id; return $ids['lead']>0;
});
t('T10 сотрудник (обязательные поля)', function() use ($wpdb,$p,$now,&$ids){
    $wpdb->insert($p.'akpp_employees', ['name'=>'Тест Мастер','email'=>'master@test.local','role'=>'mechanic','percent'=>40,'is_active'=>1,'payment_type'=>'percent','salary'=>0,'schedule_type'=>'5/2','schedule_mask'=>'1111100','absence_penalty'=>0,'created_at'=>$now]);
    $ids['emp']=$wpdb->insert_id; return $ids['emp']>0;
});
