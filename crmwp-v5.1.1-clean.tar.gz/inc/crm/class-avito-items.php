<?php
/**
 * АКПП45 CRM - Курирование объявлений Avito (каталог API: Объявления).
 * Эндпоинты: GET /core/v1/items, PUT /core/v1/items/{id}/price, DELETE /core/v1/items/{id}
 *
 * @package AKPP_CRM
 * @version 5.1.1
 */

if (!defined('ABSPATH')) exit;

class AKPP_Avito_Items {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_ajax_akpp_avito_items_refresh', [$this, 'ajax_refresh']);
        add_action('wp_ajax_akpp_avito_items_price', [$this, 'ajax_price']);
        add_action('wp_ajax_akpp_avito_items_deactivate', [$this, 'ajax_deactivate']);
    }

    /** Список объявлений (кэш 10 мин) */
    public function get_items($force = false) {
        if (!$force) {
            $c = get_transient('akpp_avito_items');
            if ($c !== false) return $c;
        }
        if (!class_exists('AKPP_Avito_API')) return ['error' => 'AKPP_Avito_API не загружен'];
        $r = AKPP_Avito_API::get_instance()->make_request('/core/v1/items');
        if (is_wp_error($r)) return ['error' => $r->get_error_message()];
        $out = ['items' => $r['items'] ?? (is_array($r) ? $r : [])];
        set_transient('akpp_avito_items', $out, 600);
        return $out;
    }

    /** Правка цены */
    public function set_price($item_id, $price) {
        if (!class_exists('AKPP_Avito_API')) return new WP_Error('no_api', 'AKPP_Avito_API не загружен');
        $r = AKPP_Avito_API::get_instance()->make_request('/core/v1/items/' . intval($item_id) . '/price', 'PUT', ['price' => intval($price)]);
        delete_transient('akpp_avito_items');
        return $r;
    }

    /** Снятие с публикации */
    public function deactivate($item_id) {
        if (!class_exists('AKPP_Avito_API')) return new WP_Error('no_api', 'AKPP_Avito_API не загружен');
        $r = AKPP_Avito_API::get_instance()->make_request('/core/v1/items/' . intval($item_id), 'DELETE');
        delete_transient('akpp_avito_items');
        return $r;
    }

    private function guard() {
        if (!current_user_can('akpp_manage_integrations')) wp_send_json_error(['message' => 'Недостаточно прав']);
        check_ajax_referer('akpp_avito_items', 'nonce');
    }

    public function ajax_refresh() {
        $this->guard();
        wp_send_json_success($this->get_items(true));
    }

    public function ajax_price() {
        $this->guard();
        $r = $this->set_price($_POST['item_id'] ?? 0, $_POST['price'] ?? 0);
        if (is_wp_error($r)) wp_send_json_error(['message' => $r->get_error_message()]);
        wp_send_json_success($r);
    }

    public function ajax_deactivate() {
        $this->guard();
        $r = $this->deactivate($_POST['item_id'] ?? 0);
        if (is_wp_error($r)) wp_send_json_error(['message' => $r->get_error_message()]);
        wp_send_json_success($r);
    }
}
