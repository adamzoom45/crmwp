<?php
/**
 * АКПП45 CRM - Webhook Авито: принимает события и передаёт в мессенджер v2.
 * Сам в БД не пишет — всё делает AKPP_Avito_Messenger::handle_webhook().
 *
 * @package AKPP_CRM
 * @version 5.1.1
 */

if (!defined('ABSPATH')) exit;

class AKPP_Avito_Webhook {

    public function __construct() {
        add_action('rest_api_init', [$this, 'register_webhook_route']);
    }

    public function register_webhook_route() {
        register_rest_route('akpp/v1', '/avito-webhook', [
            'methods'             => 'POST',
            'callback'            => [$this, 'handle_incoming_webhook'],
            'permission_callback' => '__return_true',
        ]);
    }

    public function handle_incoming_webhook($request) {
        $data = $request->get_json_params();

        if (empty($data) || empty($data['type']) || empty($data['object'])) {
            return new WP_REST_Response(['error' => 'Invalid payload structure'], 400);
        }

        try {
            if (class_exists('AKPP_Avito_Messenger')) {
                AKPP_Avito_Messenger::get_instance()->handle_webhook(
                    sanitize_text_field($data['type']),
                    $data['object']
                );
            }
            return new WP_REST_Response(['success' => true], 200);
        } catch (Exception $e) {
            error_log('[AKPP Avito Webhook] Exception: ' . $e->getMessage());
            return new WP_REST_Response(['success' => true, 'logged' => true], 200);
        }
    }
}
