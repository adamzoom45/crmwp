<?php
/**
 * АКПП45 CRM - Avito Messenger v2: чаты -> лиды + webhook-обработчик.
 * Колонки БД: lead_messages(sender_type, external_id), leads(client_phone NOT NULL).
 *
 * @package AKPP_CRM
 * @version 5.1.1
 */

if (!defined('ABSPATH')) exit;

class AKPP_Avito_Messenger {
    private static $instance = null;

    public static function get_instance() {
        if (null === self::$instance) self::$instance = new self();
        return self::$instance;
    }

    private function __construct() {
        add_action('wp_ajax_akpp_avito_sync_chats', [$this, 'ajax_sync_chats']);
        add_action('akpp_avito_cron_sync', [$this, 'sync_all']);

        if (get_option('akpp_avito_auto_sync', 0) && !wp_next_scheduled('akpp_avito_cron_sync')) {
            wp_schedule_event(time() + 300, 'every_15_minutes', 'akpp_avito_cron_sync');
        }
    }

    public function ajax_sync_chats() {
        if (!current_user_can('akpp_manage_integrations')) {
            wp_send_json_error(['message' => 'Недостаточно прав']);
        }
        check_ajax_referer('akpp_avito_sync', 'nonce');
        wp_send_json_success($this->sync_all());
    }

    /**
     * Полная синхронизация: чаты -> лиды -> сообщения
     */
    public function sync_all() {
        if (!class_exists('AKPP_Avito_API')) return ['error' => 'AKPP_Avito_API не загружен'];

        $api = AKPP_Avito_API::get_instance();
        $resp = $api->get_chats(50);
        if (is_wp_error($resp)) return ['error' => $resp->get_error_message()];

        $chats = $resp['chats'] ?? $resp['items'] ?? [];
        if (empty($chats)) return ['new_chats' => 0, 'new_leads' => 0, 'new_messages' => 0];

        $stats = ['new_chats' => 0, 'new_leads' => 0, 'new_messages' => 0, 'errors' => []];
        foreach ($chats as $chat) {
            $r = $this->process_chat($chat, $api);
            $stats['new_chats']    += $r['new_chat'] ? 1 : 0;
            $stats['new_leads']    += $r['new_lead'] ? 1 : 0;
            $stats['new_messages'] += $r['new_messages'];
            if (!empty($r['error'])) $stats['errors'][] = $r['error'];
        }
        return $stats;
    }

    private function process_chat($chat, $api) {
        global $wpdb;
        $chat_id = (string) ($chat['id'] ?? '');
        if ($chat_id === '') return ['new_chat' => false, 'new_lead' => false, 'new_messages' => 0, 'error' => 'No chat ID'];

        $chats_table = $wpdb->prefix . 'akpp_avito_chats';
        $existing = $wpdb->get_row($wpdb->prepare("SELECT * FROM $chats_table WHERE avito_chat_id = %s", $chat_id));

        $new_chat = !$existing;
        $new_lead = false;
        $lead_id  = $existing ? (int) $existing->lead_id : 0;

        if ($lead_id === 0) {
            $lead_id  = $this->create_lead_from_chat($chat);
            $new_lead = $lead_id > 0;
        }

        $chat_data = [
            'avito_chat_id'   => $chat_id,
            'lead_id'         => $lead_id,
            'item_id'         => (int) ($chat['item']['id'] ?? 0),
            'client_name'     => sanitize_text_field($chat['user']['name'] ?? 'Клиент Авито'),
            'client_id'       => (int) ($chat['user']['id'] ?? 0),
            'last_message'    => sanitize_textarea_field($chat['last_message']['text'] ?? ''),
            'last_message_at' => sanitize_text_field($chat['last_message']['created_at'] ?? current_time('mysql')),
            'unread_count'    => (int) ($chat['unread_count'] ?? 0),
        ];

        if ($existing) {
            $wpdb->update($chats_table, $chat_data, ['id' => (int) $existing->id]);
        } else {
            $chat_data['created_at'] = current_time('mysql');
            $chat_data['updated_at'] = current_time('mysql');
            $wpdb->insert($chats_table, $chat_data);
        }

        return [
            'new_chat'     => $new_chat,
            'new_lead'     => $new_lead,
            'new_messages' => $this->sync_messages($chat_id, $lead_id, $api),
        ];
    }

    /**
     * Лид из чата. client_phone NOT NULL -> пустая строка, телефон уточнит менеджер.
     */
    private function create_lead_from_chat($chat) {
        global $wpdb;
        $leads_table = $wpdb->prefix . 'akpp_leads';

        $client_name   = sanitize_text_field($chat['user']['name'] ?? 'Клиент Авито');
        $chat_id       = (string) ($chat['id'] ?? '');
        $item_id       = (int) ($chat['item']['id'] ?? 0);
        $item_title    = sanitize_text_field($chat['item']['title'] ?? '');
        $first_message = sanitize_textarea_field($chat['last_message']['text'] ?? '');

        $existing_lead = $wpdb->get_var($wpdb->prepare(
            "SELECT id FROM $leads_table WHERE client_name = %s AND source = 'avito' LIMIT 1",
            $client_name
        ));
        if ($existing_lead) return (int) $existing_lead;

        $wpdb->insert($leads_table, [
            'client_name'     => $client_name,
            'client_phone'    => '',
            'car_brand'       => $item_title ?: 'Объявление Авито',
            'problem'         => $first_message ?: 'Обращение из чата Авито',
            'status'          => 'new',
            'source'          => 'avito',
            'avito_dialog_id' => is_numeric($chat_id) ? (int) $chat_id : 0,
            'created_at'      => current_time('mysql'),
            'updated_at'      => current_time('mysql'),
        ]);

        return (int) $wpdb->insert_id;
    }

    /**
     * Сообщения чата -> lead_messages (sender_type + external_id)
     */
    private function sync_messages($chat_id, $lead_id, $api) {
        if ($lead_id === 0) return 0;

        global $wpdb;
        $messages_table = $wpdb->prefix . 'akpp_lead_messages';
        if ($wpdb->get_var("SHOW TABLES LIKE '$messages_table'") !== $messages_table) return 0;

        $resp = $api->get_chat_messages($chat_id, 20);
        if (is_wp_error($resp)) return 0;

        $messages = $resp['messages'] ?? $resp['items'] ?? [];
        if (empty($messages)) return 0;

        $new = 0;
        foreach ($messages as $msg) {
            $msg_id = (string) ($msg['id'] ?? '');
            if ($msg_id === '') continue;

            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $messages_table WHERE external_id = %s",
                'avito_' . $msg_id
            ));
            if ($exists) continue;

            $direction = (($msg['direction'] ?? 'in') === 'out') ? 'outgoing' : 'incoming';

            $wpdb->insert($messages_table, [
                'lead_id'     => $lead_id,
                'user_id'     => 0,
                'sender_type' => ($direction === 'outgoing') ? 'manager' : 'client',
                'message'     => sanitize_textarea_field($msg['text'] ?? ''),
                'is_read'     => 0,
                'created_at'  => sanitize_text_field($msg['created_at'] ?? current_time('mysql')),
                'external_id' => 'avito_' . $msg_id,
            ]);
            $new++;
        }
        return $new;
    }

    /**
     * Webhook от Авито: dialog.created / message.created -> чат + лид + сообщение
     */
    public function handle_webhook($type, $object) {
        global $wpdb;
        $chats_table    = $wpdb->prefix . 'akpp_avito_chats';
        $messages_table = $wpdb->prefix . 'akpp_lead_messages';

        if ($type === 'dialog.created') {
            $chat_id = (string) ($object['id'] ?? '');
            if ($chat_id === '') return ['ok' => false];
            $exists = $wpdb->get_var($wpdb->prepare("SELECT id FROM $chats_table WHERE avito_chat_id = %s", $chat_id));
            if (!$exists) {
                $wpdb->insert($chats_table, [
                    'avito_chat_id' => $chat_id,
                    'client_name'   => sanitize_text_field($object['user']['name'] ?? 'Клиент Авито'),
                    'client_id'     => (int) ($object['user']['id'] ?? 0),
                    'item_id'       => (int) ($object['item']['id'] ?? 0),
                    'created_at'    => current_time('mysql'),
                    'updated_at'    => current_time('mysql'),
                ]);
            }
            return ['ok' => true];
        }

        if ($type === 'message.created' || $type === 'message.updated') {
            $msg_id  = (string) ($object['id'] ?? '');
            $chat_id = (string) ($object['dialog_id'] ?? '');
            if ($msg_id === '' || $chat_id === '') return ['ok' => false];

            $exists = $wpdb->get_var($wpdb->prepare(
                "SELECT id FROM $messages_table WHERE external_id = %s",
                'avito_' . $msg_id
            ));
            if ($exists) return ['ok' => true, 'dup' => true];

            $chat = $wpdb->get_row($wpdb->prepare("SELECT * FROM $chats_table WHERE avito_chat_id = %s", $chat_id));
            if (!$chat) {
                $wpdb->insert($chats_table, [
                    'avito_chat_id' => $chat_id,
                    'client_name'   => 'Клиент Авито #' . (int) ($object['author_id'] ?? 0),
                    'client_id'     => (int) ($object['author_id'] ?? 0),
                    'created_at'    => current_time('mysql'),
                    'updated_at'    => current_time('mysql'),
                ]);
                $chat = $wpdb->get_row($wpdb->prepare("SELECT * FROM $chats_table WHERE avito_chat_id = %s", $chat_id));
            }

            $lead_id = (int) ($chat->lead_id ?? 0);
            if ($lead_id === 0) {
                $lead_id = $this->create_lead_from_chat([
                    'id'   => $chat_id,
                    'user' => ['id' => (int) ($chat->client_id ?? 0), 'name' => $chat->client_name],
                    'item' => ['id' => (int) ($chat->item_id ?? 0)],
                    'last_message' => ['text' => sanitize_textarea_field($object['text'] ?? '')],
                ]);
                $wpdb->update($chats_table, ['lead_id' => $lead_id], ['id' => (int) $chat->id]);
            }

            $wpdb->insert($messages_table, [
                'lead_id'     => $lead_id,
                'user_id'     => 0,
                'sender_type' => 'client',
                'message'     => sanitize_textarea_field($object['text'] ?? ''),
                'is_read'     => 0,
                'created_at'  => current_time('mysql'),
                'external_id' => 'avito_' . $msg_id,
            ]);

            return ['ok' => true, 'lead_id' => $lead_id];
        }

        return ['ok' => false];
    }
}
