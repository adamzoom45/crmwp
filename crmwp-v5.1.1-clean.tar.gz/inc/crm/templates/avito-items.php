<?php if (!defined('ABSPATH')) exit; ?>
<div style="margin:6px 0 14px;display:flex;gap:10px;align-items:center">
  <button type="button" id="akpp-items-refresh" class="button" style="background:#12352a;border:1px solid #1f6f4c;color:#7ef0b2">🔄 Обновить список</button>
  <span style="color:#718096;font-size:12px">Данные кэшируются 10 минут</span>
</div>
<?php
$res = class_exists('AKPP_Avito_Items') ? AKPP_Avito_Items::get_instance()->get_items() : ['error' => 'Класс AKPP_Avito_Items не загружен'];
if (!empty($res['error'])): ?>
  <div style="background:#332b12;border-left:4px solid #ffc107;padding:14px 18px;border-radius:8px;color:#ffe9a8">
    ⚠️ <?php echo esc_html($res['error']); ?> — укажите Client ID / Client Secret в табе «⚙️ Настройки API» и проверьте, что у кабинета Avito подключена подписка API.
  </div>
<?php else: $items = (array) ($res['items'] ?? []); ?>
  <table class="widefat" style="background:transparent;border:1px solid #2d3748;border-radius:12px;color:#e2e8f0">
    <thead><tr style="background:#12161f;color:#a0aec0"><th>ID</th><th>Объявление</th><th>Статус</th><th>Цена</th><th style="width:190px">Действия</th></tr></thead>
    <tbody>
    <?php if (empty($items)): ?><tr><td colspan="5" style="color:#718096;text-align:center;padding:24px">Объявлений нет</td></tr><?php endif; ?>
    <?php foreach ($items as $it): ?>
      <tr>
        <td><?php echo (int) ($it['id'] ?? 0); ?></td>
        <td><?php echo esc_html($it['title'] ?? '—'); ?></td>
        <td><?php echo esc_html($it['status'] ?? '—'); ?></td>
        <td><?php echo number_format((float) ($it['price'] ?? 0), 0, ',', ' '); ?> ₽</td>
        <td>
          <button type="button" class="button akpp-item-price" data-id="<?php echo (int) ($it['id'] ?? 0); ?>" style="background:#12352a;border:1px solid #1f6f4c;color:#7ef0b2">💰 Цена</button>
          <button type="button" class="button akpp-item-off" data-id="<?php echo (int) ($it['id'] ?? 0); ?>" style="background:#3a1a1f;border:1px solid #a33;color:#ffb3bc">🚫 Снять</button>
        </td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table>
<?php endif; ?>
<script>
(function(){
  var nonce = '<?php echo wp_create_nonce('akpp_avito_items'); ?>';
  function call(action, data, cb) {
    var fd = new FormData();
    fd.append('action', action);
    fd.append('nonce', nonce);
    for (var k in data) fd.append(k, data[k]);
    fetch(ajaxurl, { method: 'POST', body: fd, credentials: 'same-origin' })
      .then(function(r){ return r.json(); })
      .then(cb)
      .catch(function(){ alert('Ошибка соединения'); });
  }
  document.getElementById('akpp-items-refresh').addEventListener('click', function(){
    call('akpp_avito_items_refresh', {}, function(){ location.reload(); });
  });
  document.querySelectorAll('.akpp-item-price').forEach(function(b){
    b.addEventListener('click', function(){
      var p = prompt('Новая цена, ₽:');
      if (p === null || p === '') return;
      call('akpp_avito_items_price', { item_id: b.dataset.id, price: p }, function(r){
        alert(r.success ? '✅ Цена обновлена' : '❌ ' + ((r.data && r.data.message) ? r.data.message : 'Ошибка API'));
        location.reload();
      });
    });
  });
  document.querySelectorAll('.akpp-item-off').forEach(function(b){
    b.addEventListener('click', function(){
      if (!confirm('Снять объявление с публикации?')) return;
      call('akpp_avito_items_deactivate', { item_id: b.dataset.id }, function(r){
        alert(r.success ? '✅ Объявление снято' : '❌ ' + ((r.data && r.data.message) ? r.data.message : 'Ошибка API'));
        location.reload();
      });
    });
  });
})();
</script>
