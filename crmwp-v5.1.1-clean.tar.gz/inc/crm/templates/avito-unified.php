<div class="wrap akpp-crm-wrap">
<style id="akpp-avito-dark">
/* akpp-avito-dark v2: перебиваем инлайн-стили шаблонов Авито */
.akpp-tab-pane{color:#e2e8f0}
.akpp-tab-pane h1,.akpp-tab-pane h2,.akpp-tab-pane h3{color:#00ff88!important}
.akpp-tab-pane [style*="background: #fff"],.akpp-tab-pane [style*="background:#fff"]{background:#1a1f2e!important;border:1px solid #2d3748!important;box-shadow:none!important;color:#e2e8f0!important;border-radius:14px!important}
.akpp-tab-pane [style*="background: #f8f9fa"],.akpp-tab-pane [style*="background:#f8f9fa"]{background:#12161f!important;border-color:#2d3748!important;color:#a0aec0!important}
.akpp-tab-pane [style*="background: #f1f3f4"],.akpp-tab-pane [style*="background:#f1f3f4"]{background:#2d3748!important;color:#e2e8f0!important}
.akpp-tab-pane [style*="background: #e7f3ff"],.akpp-tab-pane [style*="background:#e7f3ff"]{background:#12352a!important}
.akpp-tab-pane [style*="background: #fff3cd"]{background:#332b12!important;color:#ffe9a8!important;border-left:4px solid #ffc107!important}
.akpp-tab-pane [style*="background: #d4edda"]{background:#12352a!important;color:#9ff0b8!important;border-left:4px solid #28a745!important}
.akpp-tab-pane [style*="background: #f8d7da"]{background:#3a1a1f!important;color:#ffb3bc!important;border-left:4px solid #dc3545!important}
.akpp-tab-pane [style*="solid #ddd"],.akpp-tab-pane [style*="solid #eee"]{border-color:#2d3748!important}
.akpp-tab-pane td,.akpp-tab-pane p,.akpp-tab-pane label,.akpp-tab-pane li{color:#e2e8f0!important}
.akpp-tab-pane th,.akpp-tab-pane thead{background:#12161f!important;color:#a0aec0!important}
.akpp-tab-pane input,.akpp-tab-pane select,.akpp-tab-pane textarea{background:#0a0f1c!important;border:1px solid #2d3748!important;color:#fff!important;border-radius:9px!important}
.akpp-tab-pane a{color:#41d2e2!important}
.akpp-tab-pane [class*="token-info"]{background:#12161f!important;color:#a0aec0!important}
</style>
  <div style="display:flex;gap:8px;margin:0 0 18px;border-bottom:1px solid #2d3748;padding-bottom:0">
    <button type="button" class="akpp-tab-btn active" data-tab="akpp-tab-dialogs" style="padding:10px 20px;border:none;border-bottom:3px solid #00ff88;background:transparent;color:#00ff88;font-weight:700;cursor:pointer">💬 Диалоги</button>
    <button type="button" class="akpp-tab-btn" data-tab="akpp-tab-settings" style="padding:10px 20px;border:none;border-bottom:3px solid transparent;background:transparent;color:#a0aec0;font-weight:700;cursor:pointer">⚙️ Настройки API</button>
    <button type="button" class="akpp-tab-btn" data-tab="akpp-tab-items" style="padding:10px 20px;border:none;border-bottom:3px solid transparent;background:transparent;color:#a0aec0;font-weight:700;cursor:pointer">📦 Объявления</button>
  </div>
  <div id="akpp-tab-dialogs" class="akpp-tab-pane">
    <?php include AKPP_CRM_PATH . 'templates/avito-dialogs.php'; ?>
  </div>
  <div id="akpp-tab-settings" class="akpp-tab-pane" style="display:none">
    <?php include AKPP_CRM_PATH . 'templates/avito-settings.php'; ?>
  </div>
  <div id="akpp-tab-items" class="akpp-tab-pane" style="display:none">
    <?php include AKPP_CRM_PATH . 'templates/avito-items.php'; ?>
  </div>
  <script>
  (function(){
    var btns = document.querySelectorAll('.akpp-tab-btn');
    btns.forEach(function(b){
      b.addEventListener('click', function(){
        btns.forEach(function(x){
          x.classList.remove('active');
          x.style.borderBottomColor = 'transparent';
          x.style.color = '#a0aec0';
        });
        b.classList.add('active');
        b.style.borderBottomColor = '#00ff88';
        b.style.color = '#00ff88';
        document.querySelectorAll('.akpp-tab-pane').forEach(function(p){ p.style.display = 'none'; });
        var t = document.getElementById(b.getAttribute('data-tab'));
        if (t) t.style.display = 'block';
      });
    });
  })();
  </script>
</div>
