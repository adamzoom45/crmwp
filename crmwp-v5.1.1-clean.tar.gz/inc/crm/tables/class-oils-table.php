<?php
/**
 * Класс для таблицы масел в админке
 * 
 * @package AKPP45_CRM
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WP_List_Table')) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class AKPP_Oils_Table extends WP_List_Table {
    
    private $table_name;
    
    public function __construct() {
        parent::__construct([
            'singular' => 'oil',
            'plural' => 'oils',
            'ajax' => false
        ]);
        
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'akpp_oils';
    }
    
    /**
     * Получение данных для таблицы
     */
    public function prepare_items() {
        global $wpdb;
        
        $per_page = 20;
        $current_page = $this->get_pagenum();
        $offset = ($current_page - 1) * $per_page;
        
        // Фильтры
        $type_filter = isset($_GET['type_filter']) ? sanitize_text_field($_GET['type_filter']) : 'all';
        $search = isset($_GET['s']) ? sanitize_text_field($_GET['s']) : '';
        
        // Построение WHERE
        $where = [];
        $params = [];
        
        if ($type_filter !== 'all') {
            $where[] = "type = %s";
            $params[] = $type_filter;
        }
        
        if (!empty($search)) {
            $where[] = "(name LIKE '%%%s%%' OR viscosity LIKE '%%%s%%')";
            $params[] = $search;
            $params[] = $search;
        }
        
        $where_clause = !empty($where) ? "WHERE " . implode(" AND ", $where) : "";
        
        // Сортировка
        $orderby = isset($_GET['orderby']) ? sanitize_sql_orderby($_GET['orderby']) : 'name';
        $order = isset($_GET['order']) && strtoupper($_GET['order']) === 'ASC' ? 'ASC' : 'DESC';
        
        // Получение общего количества
        $count_query = "SELECT COUNT(*) FROM {$this->table_name} {$where_clause}";
        if (!empty($params)) {
            $count_query = $wpdb->prepare($count_query, ...$params);
        }
        $total_items = $wpdb->get_var($count_query);
        
        // Получение данных
        $query = "SELECT * FROM {$this->table_name} {$where_clause} ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
        $params[] = $per_page;
        $params[] = $offset;
        
        $query = $wpdb->prepare($query, ...$params);
        $this->items = $wpdb->get_results($query);
        
        // Настройка пагинации
        $this->set_pagination_args([
            'total_items' => $total_items,
            'per_page' => $per_page,
            'total_pages' => ceil($total_items / $per_page)
        ]);
        
        $this->process_bulk_action();
    }
    
    /**
     * Определение колонок
     */
    public function get_columns() {
        return [
            'cb' => '<input type="checkbox" />',
            'id' => 'ID',
            'name' => 'Наименование',
            'type' => 'Тип',
            'viscosity' => 'Вязкость',
            'specifications' => 'Спецификации',
            'fill_volume' => 'Объем заливки',
            'price_per_liter' => 'Цена за литр',
            'actions' => 'Действия'
        ];
    }
    
    /**
     * Сортируемые колонки
     */
    public function get_sortable_columns() {
        return [
            'id' => ['id', false],
            'name' => ['name', true],
            'type' => ['type', false],
            'viscosity' => ['viscosity', false],
            'price_per_liter' => ['price_per_liter', false]
        ];
    }
    
    /**
     * Массовые действия
     */
    public function get_bulk_actions() {
        return [
            'delete' => 'Удалить',
            'export' => 'Экспорт в CSV'
        ];
    }
    
    /**
     * Обработка массовых действий
     */
    public function process_bulk_action() {
        global $wpdb;
        
        if (!$this->current_action()) return;
        
        $oil_ids = isset($_GET['oil']) ? array_map('intval', $_GET['oil']) : [];
        
        if (empty($oil_ids)) return;
        
        $ids_placeholder = implode(',', array_fill(0, count($oil_ids), '%d'));
        
        switch ($this->current_action()) {
            case 'delete':
                $wpdb->query($wpdb->prepare(
                    "DELETE FROM {$this->table_name} WHERE id IN ({$ids_placeholder})",
                    $oil_ids
                ));
                echo '<div class="notice notice-success"><p>Масла удалены</p></div>';
                break;
                
            case 'export':
                $this->export_to_csv($oil_ids);
                break;
        }
    }
    
    /**
     * Экспорт в CSV
     */
    private function export_to_csv($ids) {
        global $wpdb;
        
        $ids_placeholder = implode(',', array_fill(0, count($ids), '%d'));
        $items = $wpdb->get_results($wpdb->prepare(
            "SELECT * FROM {$this->table_name} WHERE id IN ({$ids_placeholder})",
            $ids
        ));
        
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="oils_export_' . date('Y-m-d') . '.csv"');
        
        $output = fopen('php://output', 'w');
        fputcsv($output, ['ID', 'Наименование', 'Тип', 'Вязкость', 'Спецификации', 'Объем заливки (л)', 'Цена за литр (₽)']);
        
        foreach ($items as $item) {
            fputcsv($output, [
                $item->id,
                $item->name,
                $item->type,
                $item->viscosity,
                $item->specifications,
                $item->fill_volume,
                $item->price_per_liter
            ]);
        }
        
        fclose($output);
        exit;
    }
    
    /**
     * Отображение колонки cb (чекбокс)
     */
    protected function column_cb($item) {
        return sprintf('<input type="checkbox" name="oil[]" value="%s" />', $item->id);
    }
    
    /**
     * Отображение колонки ID
     */
    protected function column_id($item) {
        return $item->id;
    }
    
    /**
     * Отображение колонки наименования
     */
    protected function column_name($item) {
        return '<strong>' . esc_html($item->name) . '</strong>';
    }
    
    /**
     * Отображение колонки типа
     */
    protected function column_type($item) {
        $types = [
            'ATF' => '🔴 ATF',
            'CVT' => '🟢 CVT',
            'DCT' => '🔵 DCT'
        ];
        
        $type_label = $types[$item->type] ?? $item->type;
        
        return sprintf(
            '<span class="type-badge type-%s">%s</span>',
            strtolower($item->type),
            esc_html($type_label)
        );
    }
    
    /**
     * Отображение колонки вязкости
     */
    protected function column_viscosity($item) {
        return esc_html($item->viscosity);
    }
    
    /**
     * Отображение колонки спецификаций
     */
    protected function column_specifications($item) {
        $specs = json_decode($item->specifications, true);
        if (is_array($specs) && !empty($specs)) {
            return '<span title="' . esc_attr(implode(', ', $specs)) . '">' . count($specs) . ' спецификаций</span>';
        }
        return '—';
    }
    
    /**
     * Отображение колонки объема заливки
     */
    protected function column_fill_volume($item) {
        return $item->fill_volume ? $item->fill_volume . ' л' : '—';
    }
    
    /**
     * Отображение колонки цены
     */
    protected function column_price_per_liter($item) {
        return number_format($item->price_per_liter, 0, ',', ' ') . ' ₽';
    }
    
    /**
     * Отображение колонки действий
     */
    protected function column_actions($item) {
        $actions = sprintf(
            '<a href="?page=akpp-crm-oils&action=edit&id=%d" class="button button-small">✏️ Ред.</a> ',
            $item->id
        );
        
        $actions .= sprintf(
            '<button class="button button-small view-oil" data-id="%d" data-name="%s">👁️</button> ',
            $item->id,
            esc_attr($item->name)
        );
        
        $actions .= sprintf(
            '<button class="button button-small delete-oil" data-id="%d">🗑️</button>',
            $item->id
        );
        
        return $actions;
    }
    
    /**
     * Отображение по умолчанию для неизвестных колонок
     */
    protected function column_default($item, $column_name) {
        return isset($item->$column_name) ? esc_html($item->$column_name) : '—';
    }
    
    /**
     * Фильтры над таблицей
     */
    protected function extra_tablenav($which) {
        if ($which !== 'top') return;
        
        $type_filter = isset($_GET['type_filter']) ? sanitize_text_field($_GET['type_filter']) : 'all';
        ?>
        <div class="alignleft actions">
            <select name="type_filter">
                <option value="all" <?php selected($type_filter, 'all'); ?>>Все типы</option>
                <option value="ATF" <?php selected($type_filter, 'ATF'); ?>>🔴 ATF</option>
                <option value="CVT" <?php selected($type_filter, 'CVT'); ?>>🟢 CVT</option>
                <option value="DCT" <?php selected($type_filter, 'DCT'); ?>>🔵 DCT</option>
            </select>
            
            <input type="submit" name="filter_action" class="button" value="Фильтровать">
            <a href="?page=akpp-crm-oils&action=add" class="button button-primary">➕ Добавить масло</a>
        </div>
        <?php
    }
    
    /**
     * Отображение, если нет данных
     */
    public function no_items() {
        echo 'Нет масел для отображения';
    }
}
